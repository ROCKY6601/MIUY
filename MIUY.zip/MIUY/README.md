# MIUY (com.miuy.aap)

Premium dark 3D-style Android app (Kotlin + Jetpack Compose).

Screens: Splash, Home, Game (Orb Rush), Wallet (Deposit / Withdraw), Profile.

## APK kaise banaye (bina PC ke)
1. GitHub par naya repo banao (jaise `miuy`) aur is zip ki saari files upload karo
   (`.github` folder samet).
2. Repo me **Actions** tab kholo, "Build MIUY APK" chalao (ya main branch me push karo).
3. Build khatam hone par run page ke **Artifacts** me `MIUY-apk` download karo.

## Wallet rules
- Deposit / Withdraw amounts: 100, 200, 500, 1000, 3000, 5000
- Withdraw par 2% service charge (1000 withdraw = 20 charge, 980 payout)
- Daily bonus Rs 5 (24 ghante me ek baar), game reward har point = Rs 0.10

## Real payment ke liye
`Store.kt` ke `PaymentGateway` object me abhi demo logic hai (hamesha success).
Real paise ke liye wahan Razorpay/Cashfree/UPI SDK aur apna backend jodna hoga.
Balance abhi phone ki local storage me hai, isliye real paise ke liye server-side
balance zaroori hai.
