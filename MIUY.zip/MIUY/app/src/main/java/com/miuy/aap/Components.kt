package com.miuy.aap

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object C {
    val Bg = Color(0xFF070914)
    val Surface = Color(0xFF12152B)
    val Surface2 = Color(0xFF1D2142)
    val Purple = Color(0xFF7C4DFF)
    val Violet = Color(0xFFB388FF)
    val Cyan = Color(0xFF00E5FF)
    val Gold = Color(0xFFFFC857)
    val Pink = Color(0xFFFF4D8D)
    val Green = Color(0xFF2BE38B)
    val Text = Color(0xFFF2F4FF)
    val Sub = Color(0xFF9AA0C8)
}

@Composable
fun MiuyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Purple,
            secondary = C.Cyan,
            background = C.Bg,
            surface = C.Surface,
            onSurface = C.Text,
            onBackground = C.Text
        ),
        content = content
    )
}

/** 3D jaisa card: gradient, glow shadow aur upar ki chamak wali border. */
@Composable
fun Card3D(
    modifier: Modifier = Modifier,
    colors: List<Color> = listOf(C.Surface2, C.Surface),
    glow: Color = C.Purple,
    radius: Dp = 22.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    var m = modifier
        .shadow(14.dp, shape, ambientColor = glow, spotColor = glow)
        .clip(shape)
        .background(Brush.verticalGradient(colors))
        .border(
            1.dp,
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.White.copy(alpha = 0.02f))),
            shape
        )
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m, content = content)
}

/** Dabne wala 3D button: neeche ek gehri edge hoti hai jo press par daab jaati hai. */
@Composable
fun Button3D(
    text: String,
    modifier: Modifier = Modifier,
    colors: List<Color> = listOf(C.Violet, C.Purple),
    edge: Color = Color(0xFF4A22C4),
    enabled: Boolean = true,
    loading: Boolean = false,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    Box(modifier.height(58.dp).alpha(if (enabled) 1f else 0.45f)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(54.dp)
                .align(Alignment.BottomCenter)
                .clip(shape)
                .background(edge)
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(54.dp)
                .align(Alignment.TopCenter)
                .offset(y = if (pressed) 4.dp else 0.dp)
                .clip(shape)
                .background(Brush.verticalGradient(colors))
                .border(1.dp, Color.White.copy(alpha = 0.25f), shape)
                .clickable(interactionSource = src, indication = null, enabled = enabled && !loading, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.5.dp)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun AmountChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val bg = if (selected) listOf(C.Violet, C.Purple) else listOf(C.Surface2, C.Surface)
    Box(
        modifier
            .height(56.dp)
            .shadow(if (selected) 12.dp else 4.dp, shape, ambientColor = C.Purple, spotColor = C.Purple)
            .clip(shape)
            .background(Brush.verticalGradient(bg))
            .border(
                BorderStroke(1.dp, if (selected) Color.White.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.1f)),
                shape
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, color = C.Text, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = modifier)
}

@Composable
fun StatTile(label: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    Card3D(modifier, glow = tint, radius = 18.dp) {
        Column(Modifier.padding(14.dp)) {
            Text(value, color = tint, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Spacer(Modifier.height(2.dp))
            Text(label, color = C.Sub, fontSize = 12.sp)
        }
    }
}

private val timeFmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.US)

@Composable
fun TxnRow(t: Txn) {
    val (icon, tint, sign) = when (t.type) {
        "deposit" -> Triple(Icons.Rounded.ArrowDownward, C.Green, "+")
        "withdraw" -> Triple(Icons.Rounded.ArrowUpward, C.Pink, "-")
        "game" -> Triple(Icons.Rounded.SportsEsports, C.Cyan, "+")
        else -> Triple(Icons.Rounded.CardGiftcard, C.Gold, "+")
    }
    val title = when (t.type) {
        "deposit" -> "Deposit"
        "withdraw" -> "Withdraw"
        "game" -> "Game reward"
        else -> "Daily bonus"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(C.Surface.copy(alpha = 0.8f))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(tint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Text, fontWeight = FontWeight.SemiBold)
            Text(timeFmt.format(Date(t.time)) + "  •  " + t.note, color = C.Sub, fontSize = 12.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(sign + money(t.amount), color = tint, fontWeight = FontWeight.Bold)
            if (t.fee > 0) Text("fee " + money(t.fee), color = C.Sub, fontSize = 11.sp)
        }
    }
}

@Composable
fun Pill(text: String, tint: Color, icon: ImageVector = Icons.Rounded.Bolt) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(tint.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, color = tint, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
