package com.miuy.aap

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

// ---------------------------------------------------------------- HOME

@Composable
fun HomeScreen(store: Store, goWallet: (Int) -> Unit, goGame: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(store.name, 48)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Welcome back", color = C.Sub, fontSize = 13.sp)
                Text(store.name, color = C.Text, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            }
            Pill("Lv ${store.level}", C.Gold)
        }

        Card3D(
            Modifier.fillMaxWidth(),
            colors = listOf(Color(0xFF8E5CFF), Color(0xFF3A1B9E)),
            radius = 26.dp
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Total Balance", color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp)
                Text(money(store.balance), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 36.sp)
                Text("Total kamaya: " + money(store.totalEarned), color = C.Gold, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button3D(
                        "Deposit", Modifier.weight(1f),
                        colors = listOf(C.Green, Color(0xFF12A765)), edge = Color(0xFF0B7A4A),
                        icon = Icons.Rounded.ArrowDownward
                    ) { goWallet(0) }
                    Button3D(
                        "Withdraw", Modifier.weight(1f),
                        colors = listOf(C.Pink, Color(0xFFD42D6D)), edge = Color(0xFF9B1A4D),
                        icon = Icons.Rounded.ArrowUpward
                    ) { goWallet(1) }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Games", store.played.toString(), C.Cyan, Modifier.weight(1f))
            StatTile("Best score", store.best.toString(), C.Gold, Modifier.weight(1f))
            StatTile("Level", store.level.toString(), C.Violet, Modifier.weight(1f))
        }

        Card3D(Modifier.fillMaxWidth(), colors = listOf(Color(0xFF14325A), Color(0xFF0C1630)), glow = C.Cyan, onClick = goGame) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ORB RUSH", color = C.Cyan, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text(
                        "30 second me orbs pakdo, har point par ${money(PAISE_PER_POINT)} kamao.",
                        color = C.Sub, fontSize = 13.sp
                    )
                }
                Box(
                    Modifier.size(52.dp).clip(CircleShape)
                        .background(Brush.radialGradient(listOf(Color(0xFFB3F5FF), C.Cyan, Color(0xFF006C80)))),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.PlayArrow, null, tint = Color(0xFF00323D), modifier = Modifier.size(30.dp)) }
            }
        }

        val canClaim = store.canClaimBonus()
        Card3D(Modifier.fillMaxWidth(), glow = C.Gold) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.CardGiftcard, null, tint = C.Gold, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Daily Bonus ${money(BONUS_PAISE)}", color = C.Text, fontWeight = FontWeight.Bold)
                    Text(
                        if (canClaim) "Abhi claim karo" else "Agla bonus ${store.bonusWaitText()} baad",
                        color = C.Sub, fontSize = 12.sp
                    )
                }
                Button3D(
                    "Claim", Modifier.width(110.dp), enabled = canClaim,
                    colors = listOf(C.Gold, Color(0xFFE09A00)), edge = Color(0xFF9A6700)
                ) {
                    if (store.claimBonus()) Toast.makeText(ctx, "${money(BONUS_PAISE)} mil gaye!", Toast.LENGTH_SHORT).show()
                }
            }
        }

        SectionTitle("Recent activity")
        if (store.history.isEmpty()) {
            Text("Abhi koi transaction nahi. Game khelo ya deposit karo.", color = C.Sub, fontSize = 13.sp)
        } else {
            store.history.take(4).forEach { TxnRow(it) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun Avatar(name: String, size: Int) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(C.Violet, C.Purple, C.Cyan))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.firstOrNull()?.uppercase() ?: "P",
            color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = (size * 0.42f).sp
        )
    }
}

// ---------------------------------------------------------------- WALLET

private val methods = listOf("UPI", "Card", "NetBanking")
private val upiRegex = Regex("^[A-Za-z0-9._\\-]{2,}@[A-Za-z]{2,}$")

@Composable
fun WalletScreen(store: Store, mode: Int, onMode: (Int) -> Unit) {
    var selected by remember { mutableIntStateOf(AMOUNTS[0]) }
    var method by remember { mutableIntStateOf(0) }
    var upi by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var msgOk by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    val fee = selected * FEE_PERCENT / 100.0
    val receive = selected - fee

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Wallet", color = C.Text, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)

        Card3D(Modifier.fillMaxWidth(), colors = listOf(Color(0xFF8E5CFF), Color(0xFF3A1B9E)), radius = 26.dp) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Available balance", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                    Text(money(store.balance), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 32.sp)
                }
                Icon(Icons.Rounded.AccountBalanceWallet, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(40.dp))
            }
        }

        // Deposit / Withdraw switch
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Surface).padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            listOf("Deposit", "Withdraw").forEachIndexed { i, label ->
                val on = mode == i
                Box(
                    Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(14.dp))
                        .background(
                            if (on) Brush.verticalGradient(if (i == 0) listOf(C.Green, Color(0xFF12A765)) else listOf(C.Pink, Color(0xFFD42D6D)))
                            else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .clickable { onMode(i); msg = null },
                    contentAlignment = Alignment.Center
                ) { Text(label, color = if (on) Color.White else C.Sub, fontWeight = FontWeight.Bold) }
            }
        }

        SectionTitle(if (mode == 0) "Deposit amount chuno" else "Withdraw amount chuno")
        AMOUNTS.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { a ->
                    AmountChip("₹$a", selected == a, Modifier.weight(1f)) { selected = a; msg = null }
                }
            }
        }

        if (mode == 0) {
            SectionTitle("Payment method")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                methods.forEachIndexed { i, m ->
                    AmountChip(m, method == i, Modifier.weight(1f)) { method = i }
                }
            }
        } else {
            OutlinedTextField(
                value = upi,
                onValueChange = { upi = it.trim(); msg = null },
                label = { Text("Aapki UPI ID (name@bank)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = C.Text, unfocusedTextColor = C.Text,
                    focusedBorderColor = C.Purple, unfocusedBorderColor = C.Surface2,
                    focusedLabelColor = C.Violet, unfocusedLabelColor = C.Sub, cursorColor = C.Violet
                )
            )
        }

        // Summary
        Card3D(Modifier.fillMaxWidth(), glow = if (mode == 0) C.Green else C.Pink) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryRow("Amount", "₹$selected", C.Text)
                if (mode == 1) {
                    SummaryRow("Service charge ($FEE_PERCENT%)", "- ₹" + String.format("%.2f", fee), C.Pink)
                    SummaryRow("Aapko milega", "₹" + String.format("%.2f", receive), C.Green, bold = true)
                } else {
                    SummaryRow("Deposit fee", "₹0.00", C.Green)
                    SummaryRow("Wallet me add hoga", "₹$selected", C.Green, bold = true)
                }
            }
        }

        if (mode == 1) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Rounded.Info, null, tint = C.Gold, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Har withdraw par $FEE_PERCENT% service charge katta jaata hai. Wallet se poora chuna hua amount " +
                        "ghat-ta hai, aur aapko amount ka 98% milta hai. Example: ₹1000 withdraw = ₹20 charge, ₹980 payout.",
                    color = C.Sub, fontSize = 12.sp, lineHeight = 17.sp
                )
            }
        }

        msg?.let {
            Text(it, color = if (msgOk) C.Green else C.Pink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }

        if (mode == 0) {
            Button3D(
                "Deposit ₹$selected", Modifier.fillMaxWidth(), loading = busy,
                colors = listOf(C.Green, Color(0xFF12A765)), edge = Color(0xFF0B7A4A),
                icon = Icons.Rounded.ArrowDownward
            ) {
                scope.launch {
                    busy = true
                    val ok = PaymentGateway.charge(selected)
                    busy = false
                    if (ok) {
                        store.deposit(selected)
                        msgOk = true
                        msg = "₹$selected wallet me add ho gaye."
                    } else {
                        msgOk = false
                        msg = "Payment fail ho gaya. Dobara try karo."
                    }
                }
            }
        } else {
            Button3D(
                "Withdraw ₹$selected", Modifier.fillMaxWidth(), loading = busy,
                colors = listOf(C.Pink, Color(0xFFD42D6D)), edge = Color(0xFF9B1A4D),
                icon = Icons.Rounded.ArrowUpward
            ) {
                when {
                    !upiRegex.matches(upi) -> { msgOk = false; msg = "Sahi UPI ID daalo (jaise name@bank)." }
                    selected * 100L > store.balance -> { msgOk = false; msg = "Balance kam hai. Pehle deposit karo ya game khelo." }
                    else -> scope.launch {
                        busy = true
                        val ok = PaymentGateway.payout(selected, upi)
                        busy = false
                        if (ok && store.withdraw(selected, upi)) {
                            msgOk = true
                            msg = "Withdraw request ho gayi. Aapko ₹" + String.format("%.2f", receive) + " milenge."
                        } else {
                            msgOk = false
                            msg = "Withdraw fail ho gaya. Dobara try karo."
                        }
                    }
                }
            }
        }

        SectionTitle("History")
        if (store.history.isEmpty()) {
            Text("Koi transaction nahi hai.", color = C.Sub, fontSize = 13.sp)
        } else {
            store.history.forEach { TxnRow(it) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SummaryRow(label: String, value: String, tint: Color, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = C.Sub, fontSize = 14.sp)
        Text(value, color = tint, fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = if (bold) 17.sp else 14.sp)
    }
}

// ---------------------------------------------------------------- PROFILE

@Composable
fun ProfileScreen(store: Store) {
    val ctx = LocalContext.current
    var editName by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(4.dp))
        Avatar(store.name, 96)
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { draft = store.name; editName = true }) {
            Text(store.name, color = C.Text, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Rounded.Edit, null, tint = C.Violet, modifier = Modifier.size(18.dp))
        }

        Card3D(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Level ${store.level}", color = C.Gold, fontWeight = FontWeight.Bold)
                    Text("${store.totalScore % 50}/50 XP", color = C.Sub, fontSize = 13.sp)
                }
                LinearProgressIndicator(
                    progress = { store.levelProgress },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)),
                    color = C.Gold, trackColor = C.Surface
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Games", store.played.toString(), C.Cyan, Modifier.weight(1f))
            StatTile("Best", store.best.toString(), C.Gold, Modifier.weight(1f))
            StatTile("Kamaya", money(store.totalEarned), C.Green, Modifier.weight(1f))
        }

        Card3D(Modifier.fillMaxWidth(), glow = C.Cyan) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Aapka referral code", color = C.Sub, fontSize = 12.sp)
                    Text(store.referral, color = C.Cyan, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                }
                Button3D(
                    "Copy", Modifier.width(110.dp), icon = Icons.Rounded.ContentCopy,
                    colors = listOf(C.Cyan, Color(0xFF00A6BD)), edge = Color(0xFF00707F)
                ) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("referral", store.referral))
                    Toast.makeText(ctx, "Code copy ho gaya", Toast.LENGTH_SHORT).show()
                }
            }
        }

        Card3D(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Wallet rules", color = C.Text, fontWeight = FontWeight.Bold)
                Text("• Deposit / Withdraw amount: ₹100, ₹200, ₹500, ₹1000, ₹3000, ₹5000", color = C.Sub, fontSize = 13.sp)
                Text("• Withdraw par $FEE_PERCENT% service charge", color = C.Sub, fontSize = 13.sp)
                Text("• Daily bonus har 24 ghante me ek baar", color = C.Sub, fontSize = 13.sp)
                Text("• Game reward: har point = ${money(PAISE_PER_POINT)}", color = C.Sub, fontSize = 13.sp)
            }
        }

        Button3D(
            "Reset all data", Modifier.fillMaxWidth(), icon = Icons.Rounded.DeleteForever,
            colors = listOf(Color(0xFF3A3F66), Color(0xFF262A4A)), edge = Color(0xFF14172E)
        ) { confirmReset = true }
        Text("MIUY v1.0", color = C.Sub, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
    }

    if (editName) {
        AlertDialog(
            onDismissRequest = { editName = false },
            containerColor = C.Surface2,
            title = { Text("Naam badlo", color = C.Text) },
            text = {
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it.take(16) }, singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = C.Text, unfocusedTextColor = C.Text,
                        focusedBorderColor = C.Purple, unfocusedBorderColor = C.Sub, cursorColor = C.Violet
                    )
                )
            },
            confirmButton = { TextButton({ store.setName(draft); editName = false }) { Text("Save") } },
            dismissButton = { TextButton({ editName = false }) { Text("Cancel") } }
        )
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = C.Surface2,
            title = { Text("Sab data reset?", color = C.Text) },
            text = { Text("Balance, history aur score sab mit jayega.", color = C.Sub) },
            confirmButton = { TextButton({ store.reset(); confirmReset = false }) { Text("Reset", color = C.Pink) } },
            dismissButton = { TextButton({ confirmReset = false }) { Text("Cancel") } }
        )
    }
}
