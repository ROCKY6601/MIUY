package com.miuy.aap

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

const val FEE_PERCENT = 2
val AMOUNTS = listOf(100, 200, 500, 1000, 3000, 5000)
const val PAISE_PER_POINT = 10L      // har game point = Rs 0.10
const val BONUS_PAISE = 500L         // daily bonus = Rs 5
const val WELCOME_PAISE = 2000L      // pehli baar Rs 20
const val DAY_MS = 24L * 60 * 60 * 1000

fun money(paise: Long): String = "₹" + String.format(Locale.US, "%,.2f", paise / 100.0)

data class Txn(val type: String, val amount: Long, val fee: Long, val time: Long, val note: String)

/**
 * Payment gateway ka placeholder. Real paise ke liye yahan Razorpay / Cashfree / UPI SDK
 * aur aapka backend jodna hoga. Abhi ye demo mode me hamesha success deta hai.
 */
object PaymentGateway {
    suspend fun charge(rupees: Int): Boolean {
        delay(1200)
        return true
    }

    suspend fun payout(rupees: Int, upi: String): Boolean {
        delay(1200)
        return true
    }
}

class Store(context: Context) {
    private val sp = context.getSharedPreferences("miuy_store", Context.MODE_PRIVATE)

    var name by mutableStateOf(sp.getString("name", "Player") ?: "Player")
        private set
    var balance by mutableLongStateOf(sp.getLong("bal", WELCOME_PAISE))
        private set
    var played by mutableIntStateOf(sp.getInt("played", 0))
        private set
    var best by mutableIntStateOf(sp.getInt("best", 0))
        private set
    var totalScore by mutableIntStateOf(sp.getInt("total", 0))
        private set
    var lastBonus by mutableLongStateOf(sp.getLong("bonus", 0L))
        private set
    var totalEarned by mutableLongStateOf(sp.getLong("earned", 0L))
        private set

    val referral: String = sp.getString("ref", null)
        ?: ("MIUY" + (1000..9999).random()).also { sp.edit().putString("ref", it).apply() }

    val history = mutableStateListOf<Txn>()
    val scores = mutableStateListOf<Int>()

    val level: Int get() = totalScore / 50 + 1
    val levelProgress: Float get() = (totalScore % 50) / 50f

    init {
        runCatching {
            val h = JSONArray(sp.getString("hist", "[]"))
            for (i in 0 until h.length()) {
                val o = h.getJSONObject(i)
                history.add(Txn(o.getString("t"), o.getLong("a"), o.getLong("f"), o.getLong("w"), o.getString("n")))
            }
            val s = JSONArray(sp.getString("scores", "[]"))
            for (i in 0 until s.length()) scores.add(s.getInt(i))
        }
        if (!sp.contains("bal")) save()
    }

    private fun save() {
        val h = JSONArray()
        history.forEach {
            h.put(JSONObject().put("t", it.type).put("a", it.amount).put("f", it.fee).put("w", it.time).put("n", it.note))
        }
        val s = JSONArray()
        scores.forEach { s.put(it) }
        sp.edit()
            .putString("name", name)
            .putLong("bal", balance)
            .putInt("played", played)
            .putInt("best", best)
            .putInt("total", totalScore)
            .putLong("bonus", lastBonus)
            .putLong("earned", totalEarned)
            .putString("hist", h.toString())
            .putString("scores", s.toString())
            .apply()
    }

    private fun log(t: Txn) {
        history.add(0, t)
        while (history.size > 50) history.removeAt(history.size - 1)
    }

    fun setName(n: String) {
        name = n.trim().ifEmpty { "Player" }.take(16)
        save()
    }

    fun deposit(rupees: Int) {
        val p = rupees * 100L
        balance += p
        log(Txn("deposit", p, 0L, System.currentTimeMillis(), "Deposit added"))
        save()
    }

    /** Balance se poora amount katta hai; user ko amount minus 2% fee milta hai. */
    fun withdraw(rupees: Int, upi: String): Boolean {
        val p = rupees * 100L
        if (p > balance) return false
        val fee = p * FEE_PERCENT / 100
        balance -= p
        log(Txn("withdraw", p, fee, System.currentTimeMillis(), "To $upi"))
        save()
        return true
    }

    fun canClaimBonus(): Boolean = System.currentTimeMillis() - lastBonus >= DAY_MS

    fun bonusWaitText(): String {
        val left = DAY_MS - (System.currentTimeMillis() - lastBonus)
        val h = (left / 3_600_000L).coerceAtLeast(0)
        val m = ((left % 3_600_000L) / 60_000L).coerceAtLeast(0)
        return "${h}h ${m}m"
    }

    fun claimBonus(): Boolean {
        if (!canClaimBonus()) return false
        balance += BONUS_PAISE
        totalEarned += BONUS_PAISE
        lastBonus = System.currentTimeMillis()
        log(Txn("bonus", BONUS_PAISE, 0L, lastBonus, "Daily bonus"))
        save()
        return true
    }

    fun finishGame(score: Int): Long {
        val reward = score * PAISE_PER_POINT
        played += 1
        totalScore += score
        if (score > best) best = score
        scores.add(score)
        scores.sortDescending()
        while (scores.size > 5) scores.removeAt(scores.size - 1)
        if (reward > 0) {
            balance += reward
            totalEarned += reward
            log(Txn("game", reward, 0L, System.currentTimeMillis(), "Orb Rush score $score"))
        }
        save()
        return reward
    }

    fun reset() {
        sp.edit().clear().apply()
        name = "Player"
        balance = WELCOME_PAISE
        played = 0
        best = 0
        totalScore = 0
        lastBonus = 0L
        totalEarned = 0L
        history.clear()
        scores.clear()
        save()
    }
}
