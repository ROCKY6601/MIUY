package com.miuy.aap

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(applicationContext)
        setContent {
            MiuyTheme { App(store) }
        }
    }
}

@Composable
fun App(store: Store) {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1500)
        splash = false
    }
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF14102E), C.Bg, Color(0xFF05060F)))
        )
    ) {
        if (splash) Splash() else MainShell(store)
    }
}

@Composable
fun Splash() {
    val s = remember { Animatable(0.4f) }
    LaunchedEffect(Unit) { s.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.scale(s.value).size(110.dp)
                .background(Brush.linearGradient(listOf(C.Violet, C.Purple, Color(0xFF4A22C4))), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) { Text("M", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 60.sp) }
        Box(Modifier.height(18.dp))
        Text("MIUY", color = C.Text, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp, letterSpacing = 6.sp)
        Text("Play. Win. Earn.", color = C.Sub, fontSize = 14.sp)
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@Composable
fun MainShell(store: Store) {
    var tab by remember { mutableIntStateOf(0) }
    var walletMode by remember { mutableIntStateOf(0) }
    val tabs = remember {
        listOf(
            Tab("Home", Icons.Rounded.Home),
            Tab("Game", Icons.Rounded.SportsEsports),
            Tab("Wallet", Icons.Rounded.AccountBalanceWallet),
            Tab("Profile", Icons.Rounded.Person)
        )
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth().statusBarsPadding().padding(top = 12.dp)) {
            when (tab) {
                0 -> HomeScreen(store, goWallet = { walletMode = it; tab = 2 }, goGame = { tab = 1 })
                1 -> GameScreen(store)
                2 -> WalletScreen(store, walletMode) { walletMode = it }
                else -> ProfileScreen(store)
            }
        }
        Card3D(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).navigationBarsPadding(),
            radius = 28.dp
        ) {
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceAround) {
                tabs.forEachIndexed { i, t ->
                    val on = tab == i
                    Column(
                        Modifier
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { tab = i }
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(width = 52.dp, height = 32.dp)
                                .background(
                                    if (on) Brush.verticalGradient(listOf(C.Violet, C.Purple))
                                    else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)),
                                    RoundedCornerShape(16.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(t.icon, t.label, tint = if (on) Color.White else C.Sub, modifier = Modifier.size(22.dp))
                        }
                        Text(t.label, color = if (on) C.Text else C.Sub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
