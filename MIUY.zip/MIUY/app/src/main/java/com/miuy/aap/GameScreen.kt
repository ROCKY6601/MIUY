package com.miuy.aap

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.hypot
import kotlin.random.Random

/** kind: 0 = gold (+1), 1 = blue (+3), 2 = bomb (-2 aur ek life) */
class Orb(var x: Float, var y: Float, val r: Float, val v: Float, val kind: Int)

private const val ROUND_SECONDS = 30f

private fun DrawScope.drawOrb(o: Orb) {
    val c = Offset(o.x, o.y)
    val hi: Color
    val base: Color
    val lo: Color
    when (o.kind) {
        0 -> { hi = Color(0xFFFFF3B0); base = C.Gold; lo = Color(0xFFB56F00) }
        1 -> { hi = Color(0xFFB3F5FF); base = C.Cyan; lo = Color(0xFF006C80) }
        else -> { hi = Color(0xFF8A8FA8); base = Color(0xFF2A2D40); lo = Color.Black }
    }
    drawCircle(Color.Black.copy(alpha = 0.35f), o.r, c + Offset(0f, o.r * 0.28f))
    drawCircle(
        Brush.radialGradient(listOf(hi, base, lo), center = c - Offset(o.r * 0.3f, o.r * 0.3f), radius = o.r * 1.6f),
        o.r,
        c
    )
    drawCircle(Color.White.copy(alpha = 0.65f), o.r * 0.18f, c - Offset(o.r * 0.38f, o.r * 0.38f))
    if (o.kind == 2) drawCircle(C.Pink, o.r * 0.22f, c)
}

@Composable
fun GameScreen(store: Store) {
    var phase by remember { mutableIntStateOf(0) } // 0 shuru, 1 chal raha, 2 khatam
    var score by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(3) }
    var timeLeft by remember { mutableFloatStateOf(ROUND_SECONDS) }
    var reward by remember { mutableLongStateOf(0L) }
    var tick by remember { mutableLongStateOf(0L) }
    var w by remember { mutableFloatStateOf(0f) }
    var h by remember { mutableFloatStateOf(0f) }
    val orbs = remember { ArrayList<Orb>() }
    val density = LocalDensity.current.density
    val haptic = LocalHapticFeedback.current

    fun finish() {
        if (phase == 1) {
            phase = 2
            reward = store.finishGame(score)
        }
    }

    LaunchedEffect(phase) {
        if (phase != 1) return@LaunchedEffect
        orbs.clear()
        score = 0
        lives = 3
        timeLeft = ROUND_SECONDS
        var last = withFrameNanos { it }
        var spawn = 0f
        while (phase == 1) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = now
            timeLeft -= dt
            spawn += dt
            val elapsed = ROUND_SECONDS - timeLeft
            val interval = (0.75f - elapsed * 0.012f).coerceAtLeast(0.35f)
            if (spawn >= interval && w > 0f) {
                spawn = 0f
                val r = (26 + Random.nextInt(14)) * density
                val roll = Random.nextFloat()
                val kind = if (roll < 0.16f) 2 else if (roll < 0.30f) 1 else 0
                val speed = h * (0.30f + Random.nextFloat() * 0.25f + elapsed * 0.008f)
                orbs.add(Orb(r + Random.nextFloat() * (w - 2 * r), -r, r, speed, kind))
            }
            val iter = orbs.iterator()
            while (iter.hasNext()) {
                val o = iter.next()
                o.y += o.v * dt
                if (o.y - o.r > h) {
                    iter.remove()
                    if (o.kind != 2) lives--
                }
            }
            tick = now
            if (lives <= 0 || timeLeft <= 0f) {
                timeLeft = timeLeft.coerceAtLeast(0f)
                finish()
            }
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ORB RUSH", color = C.Text, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                Text("Score: $score", color = C.Gold, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(3) { i ->
                    Icon(
                        Icons.Rounded.Favorite, null,
                        tint = if (i < lives) C.Pink else C.Surface2,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
        LinearProgressIndicator(
            progress = { (timeLeft / ROUND_SECONDS).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
            color = C.Cyan,
            trackColor = C.Surface2
        )

        Card3D(Modifier.weight(1f).fillMaxWidth(), colors = listOf(Color(0xFF1A1F4A), Color(0xFF0A0C1F)), glow = C.Cyan) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { w = it.width.toFloat(); h = it.height.toFloat() }
                    .pointerInput(Unit) {
                        detectTapGestures { off ->
                            if (phase != 1) return@detectTapGestures
                            val o = orbs.lastOrNull { hypot(it.x - off.x, it.y - off.y) <= it.r * 1.25f }
                                ?: return@detectTapGestures
                            orbs.remove(o)
                            when (o.kind) {
                                0 -> score += 1
                                1 -> score += 3
                                else -> {
                                    score = (score - 2).coerceAtLeast(0)
                                    lives--
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    if (lives <= 0) finish()
                                }
                            }
                        }
                    }
            ) {
                val t = tick
                if (t < 0) return@Canvas
                // perspective jaisi grid
                val lineColor = Color.White.copy(alpha = 0.05f)
                var gy = size.height * 0.1f
                var step = 14f
                while (gy < size.height) {
                    drawLine(lineColor, Offset(0f, gy), Offset(size.width, gy), 2f)
                    step *= 1.25f
                    gy += step
                }
                for (i in 0..8) {
                    val x = size.width * i / 8f
                    drawLine(lineColor, Offset(size.width / 2f, 0f), Offset(x, size.height), 2f)
                }
                orbs.forEach { drawOrb(it) }
            }

            if (phase != 1) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                    Column(
                        Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (phase == 0) {
                            Text("Tap the orbs!", color = C.Text, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
                            Text(
                                "Gold orb +1  •  Blue orb +3\nBomb -2 aur ek life\nMiss kiya orb = ek life gayi\n" +
                                    "Har point = ${money(PAISE_PER_POINT)} wallet me",
                                color = C.Sub, textAlign = TextAlign.Center, lineHeight = 22.sp
                            )
                            if (store.scores.isNotEmpty()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.EmojiEvents, null, tint = C.Gold, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.size(6.dp))
                                    Text(
                                        "Best: " + store.scores.joinToString("  "),
                                        color = C.Gold, fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        } else {
                            Text("Game Over", color = C.Text, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
                            Text("Score $score", color = C.Gold, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            Text(
                                if (reward > 0) "+" + money(reward) + " wallet me add hue" else "Is baar koi reward nahi mila",
                                color = if (reward > 0) C.Green else C.Sub, fontWeight = FontWeight.SemiBold
                            )
                        }
                        Button3D(
                            text = if (phase == 0) "PLAY" else "PLAY AGAIN",
                            icon = if (phase == 0) Icons.Rounded.PlayArrow else Icons.Rounded.Replay,
                            modifier = Modifier.fillMaxWidth(0.7f)
                        ) { phase = 1 }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}
